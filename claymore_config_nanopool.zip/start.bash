export GPU_FORCE_64BIT_PTR=1
export GPU_MAX_HEAP_SIZE=100
export GPU_USE_SYNC_OBJECTS=1
export GPU_MAX_ALLOC_PERCENT=100
export GPU_SINGLE_ALLOC_PERCENT=100
./ethdcrminer64 -dcri 11 -epool eth-eu1.nanopool.org:9999 -ewal 0xf68f37da0df15c996a8f17acc61a6c0bed4721ec.rig1/nils-@hotmail.fr -epsw x -dcoin pasc -dpool pasc-eu1.nanopool.org:15555 -dwal 86646.1c24d21c5cbce839.rig1/nils-@hotmail.fr -dpsw x -ftime 10
